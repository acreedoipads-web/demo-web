/*
  ACREEDO DEMO CONTENT
  --------------------
  This is the only file most people need to edit.
  Replace the obvious EDIT ME values, artist names, Facebook links and wording.
  Keep quotation marks and commas in place when changing text.
*/
window.ACREEDO_CONTENT = {
  business: {
    name: "Acreedo Tattoos & Body Piercings",
    shortName: "ACREEDO",
    strapline: "TATTOOS.|PIERCINGS.|NO BS.",
    addressLines: ["5 High Street", "Abingdon, Oxfordshire", "OX14 5BB"],
    openingHours: "Wednesday—Saturday · 11:00—18:00",
    piercingHours: "Walk-ins Wednesday, Thursday and Saturday · 11:00—18:00",
    email: "EDIT-ME@example.com",
    phone: "+44 1235 000000",
    facebook: "https://www.facebook.com/EDIT-ME",
    googleReviews: "https://www.google.com/search?q=Acreedo+Tattoos+Abingdon+reviews",
    maps: "https://maps.google.com/?q=5+High+Street+Abingdon+OX14+5BB"
  },

  home: {
    heroImage: "assets/photos/tattoo-japanese-dagger.jpg",
    intro: "Independent tattooing and body piercing in the heart of Abingdon.",
    introDetail: "An established studio specialising in custom tattoos, professional body piercing and a relaxed, welcoming experience.",
    stylesHeadline: "YOUR IDEA. DONE PROPERLY.",
    stylesIntro: "Custom tattooing across a wide range of styles, built around you and made to last.",
    review: "Absolutely brilliant studio. Friendly from the minute you walk in, completely professional, and the work speaks for itself.",
    reviewName: "Featured Google review"
  },

  artists: [
    {
      name: "Zsolt",
      styles: "Black & Grey • Realism • Large Scale",
      image: "assets/photos/artist-at-work-portrait.jpg",
      availability: "NOW TAKING BOOKINGS",
      bio: "Replace this biography with the artist's real introduction, experience and preferred work.",
      facebookAlbum: "https://www.facebook.com/EDIT-ME"
    },
    {
      name: "Olek",
      styles: "Illustrative • Blackwork • Custom",
      image: "assets/photos/artist-at-work-wide.jpg",
      availability: "ENQUIRE FOR AVAILABILITY",
      bio: "Replace this biography with the artist's real introduction, experience and preferred work.",
      facebookAlbum: "https://www.facebook.com/EDIT-ME"
    },
    {
      name: "Bruno",
      styles: "Traditional • Colour • Bold Work",
      image: "assets/photos/tattoo-floral-stencil.jpg",
      availability: "NOW TAKING BOOKINGS",
      bio: "Replace this biography with the artist's real introduction, experience and preferred work.",
      facebookAlbum: "https://www.facebook.com/EDIT-ME"
    }
  ],

  portfolio: [
    { image: "assets/photos/tattoo-floral-colour.jpg", artist: "ACREEDO", style: "COLOUR / FLORAL", alt: "Colour floral shoulder tattoo" },
    { image: "assets/photos/tattoo-ornamental-hand.jpg", artist: "ACREEDO", style: "ORNAMENTAL / BLACKWORK", alt: "Ornamental blackwork hand tattoo" },
    { image: "assets/photos/tattoo-japanese-dagger.jpg", artist: "ACREEDO", style: "JAPANESE / COLOUR", alt: "Japanese colour dagger tattoo" },
    { image: "assets/photos/tattoo-eye-skull.jpg", artist: "ACREEDO", style: "SURREAL / COLOUR", alt: "Surreal eye and skull tattoo" },
    { image: "assets/photos/tattoo-2004-knee.jpg", artist: "ACREEDO", style: "SCRIPT / BLACKWORK", alt: "Blackwork script tattoo" }
  ],

  piercingPrices: [
    { title: "£20 — Ear", items: ["Lobe", "Helix", "Forward helix", "Daith", "Rook", "Snug", "Conch", "Tragus", "Anti-tragus", "Flat"], price: "£20" },
    { title: "£30 — Face & body", items: ["Lip (all)", "Nose", "Eyebrow", "Navel", "Septum", "Bridge"], price: "£30" },
    { title: "£35 — Specialist", items: ["Tongue", "Nipple", "Tongue webbing", "Smiley", "Frowny"], price: "£35" },
    { title: "£40 — Advanced", items: ["Industrial", "Dermals", "Skin divers"], price: "£40" }
  ],

  faqs: [
    ["How do I book a tattoo?", "Send an enquiry with your idea, placement, approximate size and preferred artist. We’ll reply with the next step and any deposit required."],
    ["Do you take deposits?", "Yes. A deposit secures your appointment and contributes to the final cost. Deposits are normally non-refundable."],
    ["How should I prepare?", "Eat well, hydrate, avoid alcohol for 24 hours and wear clothing that gives easy access to the area."],
    ["Can I walk in for a piercing?", "Yes — piercing walk-ins are available Wednesday, Thursday and Saturday, 11:00–18:00."],
    ["What are the age restrictions?", "Photo ID may be required. Lobe piercing is available from age 8 with a parent or legal guardian; other restrictions vary by placement."],
    ["What payment do you accept?", "Replace this answer with the payment methods the studio currently accepts."],
    ["What is your cancellation policy?", "Replace this answer with the studio's exact cancellation and deposit policy."],
    ["Where can I park?", "We are at 5 High Street in central Abingdon, close to town-centre car parks and bus routes."]
  ]
};
