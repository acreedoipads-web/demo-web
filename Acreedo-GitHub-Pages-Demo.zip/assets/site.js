(function () {
  "use strict";
  const content = window.ACREEDO_CONTENT;
  const app = document.getElementById("app");
  const business = content.business;

  const escapeHtml = (value) => String(value ?? "").replace(/[&<>'"]/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
  })[char]);
  const external = (url, label, className = "") => `<a class="${className}" href="${escapeHtml(url)}" target="_blank" rel="noreferrer">${label}</a>`;
  const routeLink = (route, label, className = "") => `<a class="${className}" href="#/${route}">${label}</a>`;

  function pageHero(index, title, subtitle) {
    return `<section class="page-hero reveal-group">
      <p>ACREEDO / ${index}</p>
      <h1>${escapeHtml(title)}</h1>
      <p>${escapeHtml(subtitle)}</p>
    </section>`;
  }

  function workGrid(items, all = false) {
    return `<div class="work-grid${all ? " all-work" : ""}">${items.map((item, index) => `
      <figure class="work-${index + 1} reveal">
        <img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.alt)}" ${index > 1 ? 'loading="lazy"' : ""}>
        <figcaption><span>${escapeHtml(item.artist)}</span><span>${escapeHtml(item.style)}</span></figcaption>
      </figure>`).join("")}</div>`;
  }

  function artistCards(limit) {
    return `<div class="artist-grid">${content.artists.slice(0, limit || content.artists.length).map((artist, index) => `
      <article class="artist artist-${index + 1} reveal">
        <img src="${escapeHtml(artist.image)}" alt="${escapeHtml(artist.name)} at Acreedo" loading="lazy">
        <h3>${escapeHtml(artist.name)}</h3>
        <p>${escapeHtml(artist.styles)}</p>
        <b>${escapeHtml(artist.availability)}</b>
        ${external(artist.facebookAlbum, "Facebook portfolio ↗")}
      </article>`).join("")}</div>`;
  }

  function homePage() {
    const lines = content.business.strapline.split("|");
    const processSteps = [
      ["01", "BOOK IN", "Send your idea, placement, approximate size and useful reference images."],
      ["02", "CONSULTATION", "Larger or more involved pieces may benefit from a proper consultation."],
      ["03", "STENCIL", "We get size and position right. Nothing starts until you are happy."],
      ["04", "TATTOO TIME", "Get comfortable. Your artist will talk you through it, then get to work."],
      ["05", "AFTERCARE", "Leave with clear guidance and contact the studio if anything is unclear."]
    ];
    const styles = ["Fine Line", "Black & Grey", "Realism", "Colour", "Traditional", "Geometric", "Custom Work", "Script", "Illustrative"];
    return `<section class="hero" aria-labelledby="hero-title">
        <div class="hero-image" style="background-image:url('${escapeHtml(content.home.heroImage)}')"></div>
        <div class="hero-shade"></div>
        <div class="hero-content">
          <p class="eyebrow">EST. ABINGDON • OXFORDSHIRE</p>
          <h1 id="hero-title">${lines.map((line, index) => index === lines.length - 1 ? `<em>${escapeHtml(line)}</em>` : escapeHtml(line)).join("<br>")}</h1>
          <div class="hero-actions">${routeLink("contact", "Start your tattoo", "button light")}${routeLink("piercing", "Walk-in piercings ↗", "text-link")}</div>
        </div>
        <p class="scroll-cue">SCROLL TO EXPLORE <span>↓</span></p>
      </section>
      <div class="marquee"><div>TATTOOS • BODY PIERCING • CUSTOM WORK • ABINGDON • OXFORDSHIRE • ESTABLISHED STUDIO • TATTOOS • BODY PIERCING • CUSTOM WORK • ABINGDON • OXFORDSHIRE • ESTABLISHED STUDIO •</div></div>
      <section class="intro cream">
        <p class="eyebrow dark">ACREEDO / 01</p>
        <h2 class="reveal">${escapeHtml(content.home.intro)}</h2>
        <div class="intro-copy reveal"><p>${escapeHtml(content.home.introDetail)}</p>${routeLink("studio", "Meet the studio →", "dark-link")}</div>
      </section>
      <section class="work-section">
        <div class="section-head reveal"><p>02 / SELECTED WORK</p><h2>GOOD WORK.<br>NO FUSS.</h2></div>
        ${workGrid(content.portfolio)}
        ${routeLink("tattoos", "View all tattoos →", "outline-button")}
      </section>
      <section class="artists cream">
        <div class="section-head dark-head reveal"><p>03 / RESIDENT ARTISTS</p><h2>MEET THE<br>ARTISTS.</h2></div>
        ${artistCards(3)}
        ${routeLink("artists", "All artists →", "dark-link")}
      </section>
      <section class="how-it-works">
        <div class="how-head reveal"><p>HOW IT WORKS / 04</p><h2>FROM IDEA<br>TO INK</h2></div>
        <figure class="process-visual reveal"><img src="assets/photos/artist-at-work-wide.jpg" alt="Tattoo artist at work inside Acreedo" loading="lazy"><figcaption><span>THE PROCESS</span><b>CALM. CLEAN. CONSIDERED.</b></figcaption></figure>
        <div class="how-grid">${processSteps.map((step) => `<article class="reveal"><span>${step[0]}</span><h3>${step[1]}</h3><p>${step[2]}</p></article>`).join("")}</div>
      </section>
      <section class="styles">
        <div class="reveal"><p class="eyebrow">TATTOOS / 05</p><h2>${escapeHtml(content.home.stylesHeadline)}</h2><p class="lead">${escapeHtml(content.home.stylesIntro)}</p>${routeLink("contact", "Talk to an artist", "button light")}</div>
        <ol>${styles.map((style, index) => `<li class="reveal"><span>0${index + 1}</span>${style}<b>↗</b></li>`).join("")}</ol>
      </section>
      <section class="piercing-home cream">
        <div class="pierce-image reveal"><img src="assets/photos/studio-aftercare.jpg" alt="Professional piercing aftercare products" loading="lazy"></div>
        <div class="pierce-copy reveal"><p class="eyebrow dark">BODY PIERCING / 06</p><h2>WALK IN.<br>GET PIERCED.</h2><p>${escapeHtml(business.piercingHours)}</p><div class="hours"><span>WALK-INS</span><strong>WED · THU · SAT<br>11:00—18:00</strong></div><p class="age">LOBES FROM AGE 8</p><div>${routeLink("piercing", "Piercing info", "button dark-button")}${routeLink("piercing-prices", "View prices →", "dark-link")}</div></div>
      </section>
      <section class="studio-home">
        <div class="section-head reveal"><p>07 / THE STUDIO</p><h2>HIGH STREET.<br>HIGH STANDARDS.</h2></div>
        <div class="studio-pair"><img class="reveal" src="assets/photos/studio-red-door.jpg" alt="Inside Acreedo on Abingdon High Street" loading="lazy"><div class="reveal"><p>An independent, established studio with distinct artists, honest advice and a relaxed atmosphere.</p>${routeLink("studio", "Step inside →", "text-link")}</div></div>
      </section>
      <section class="reviews cream reveal"><p class="eyebrow dark">WHAT PEOPLE SAY / 08</p><p class="stars" aria-label="Five stars">★★★★★</p><blockquote>“${escapeHtml(content.home.review)}”</blockquote><p>— ${escapeHtml(content.home.reviewName)}</p>${external(business.googleReviews, "Read our Google reviews →", "dark-link")}</section>
      <section class="newsletter reveal"><p class="eyebrow">STUDIO NEWS / 09</p><h2>FRESH WORK.<br>GUEST SPOTS.<br>NO SPAM.</h2><form class="newsletter-form"><label for="newsletter-email">Email address</label><div><input id="newsletter-email" type="email" placeholder="you@example.com" required><button class="button light" type="submit">Subscribe →</button></div><p class="form-status" aria-live="polite"></p></form></section>
      <section class="location">
        <p class="eyebrow">FIND US / 10</p><h2 class="reveal">5 HIGH STREET.<br><em>ABINGDON.</em></h2>
        <div class="location-photo reveal"><img src="assets/photos/studio-high-street.jpg" alt="Acreedo Tattoos on Abingdon High Street" loading="lazy"><span>IN THE HEART OF ABINGDON</span></div>
        <div class="location-grid reveal"><address>${business.addressLines.map(escapeHtml).join("<br>")}</address><p>${escapeHtml(business.openingHours)}<br><br>${escapeHtml(business.piercingHours)}</p><div>${external(business.maps, "Get directions ↗", "button light")}<br>${routeLink("contact", "Message the studio", "text-link")}</div></div>
      </section>`;
  }

  function tattoosPage() {
    return `${pageHero("01", "TATTOOS.", "Custom work, made in Abingdon.")}<section class="sub-content"><div class="page-intro-copy reveal"><h2>WORK MADE<br>TO LAST.</h2><p>A selection of work from the Acreedo team. Replace or add images in <code>assets/content.js</code>.</p></div>${workGrid(content.portfolio, true)}${routeLink("contact", "Start your enquiry →", "outline-button")}</section>`;
  }

  function piercingPage() {
    return `${pageHero("02", "PIERCING.", "Professional body piercing. Honest advice.")}<section class="sub-content"><div class="split-info"><img class="reveal" src="assets/photos/studio-aftercare.jpg" alt="Piercing jewellery and aftercare" loading="lazy"><div class="reveal"><h2>WALK IN.<br>GET PIERCED.</h2><p>${escapeHtml(business.piercingHours)}</p><div class="hours"><span>WALK-INS</span><strong>WED · THU · SAT<br>11:00—18:00</strong></div><p>Lobes are available from age 8 with a parent or legal guardian. Photo ID may be required. Replace this paragraph with the studio's exact current policy.</p>${routeLink("piercing-prices", "See piercing prices", "button light")}</div></div></section>`;
  }

  function pricesPage() {
    return `${pageHero("03", "PIERCING PRICES.", "Clear prices. Professional care.")}<section class="sub-content price-page">${content.piercingPrices.map((group) => `<article class="reveal"><h2>${escapeHtml(group.title)}</h2>${group.items.map((item) => `<p><span>${escapeHtml(item)}</span><i></i><b>${escapeHtml(group.price)}</b></p>`).join("")}</article>`).join("")}<aside class="reveal"><h2>GOOD TO KNOW.</h2><p>All listed prices are per piercing. Jewellery choices may affect the final price. Replace this note with your exact studio wording.</p></aside></section>`;
  }

  function artistsPage() {
    return `${pageHero("04", "ARTISTS.", "Different hands. One high standard.")}<section class="sub-content"><div class="page-intro-copy reveal"><h2>MEET THE<br>TEAM.</h2><p>Choose the artist whose work feels right for your idea. Each portfolio button opens the Facebook album link set in <code>assets/content.js</code>.</p></div><div class="artist-directory">${content.artists.map((artist) => `<article class="reveal"><img src="${escapeHtml(artist.image)}" alt="${escapeHtml(artist.name)}" loading="lazy"><div><h2>${escapeHtml(artist.name)}</h2><p>${escapeHtml(artist.styles)}</p><b>${escapeHtml(artist.availability)}</b><p class="artist-bio">${escapeHtml(artist.bio)}</p>${external(artist.facebookAlbum, "Facebook portfolio ↗", "button light")}</div></article>`).join("")}</div></section>`;
  }

  function studioPage() {
    return `${pageHero("05", "THE STUDIO.", "5 High Street, Abingdon.")}<section class="sub-content editorial-copy"><div class="page-intro-copy reveal"><h2>GOOD TATTOOS.<br>GOOD PEOPLE.</h2><p>An independent, established studio on Abingdon High Street. Distinct artists, honest advice and a relaxed atmosphere.</p></div><img class="reveal" src="assets/photos/studio-red-door.jpg" alt="Acreedo studio entrance" loading="lazy"><p class="reveal">The atmosphere is relaxed, the standards are high and the advice is honest. Come in with a fully formed idea or just the beginning of one.</p><p class="reveal">We use professional equipment, careful hygiene practices and clear aftercare guidance. Replace this text with your exact studio information.</p><div class="studio-detail-grid"><img class="reveal" src="assets/photos/studio-inks.jpg" alt="Tattoo inks in the Acreedo studio" loading="lazy"><img class="reveal" src="assets/photos/artist-at-work-portrait.jpg" alt="Tattoo artist working at Acreedo" loading="lazy"></div></section>`;
  }

  function faqPage() {
    return `${pageHero("06", "FAQ.", "Useful answers before you visit.")}<section class="sub-content"><div class="page-intro-copy reveal"><h2>GOOD TO<br>KNOW.</h2><p>Edit every answer in <code>assets/content.js</code> before using this demo publicly.</p></div><div class="faq-list">${content.faqs.map((faq, index) => `<details class="reveal"><summary><span>0${index + 1}</span>${escapeHtml(faq[0])}<b>+</b></summary><p>${escapeHtml(faq[1])}</p></details>`).join("")}</div></section>`;
  }

  function contactPage() {
    return `${pageHero("07", "CONTACT.", "Tell us what you have in mind.")}<section class="sub-content form-wrap"><div class="reveal"><h2>SEND YOUR<br>IDEA.</h2><p>Include your idea, placement, approximate size and any useful references.</p><address>${business.addressLines.map(escapeHtml).join("<br>")}<br><br><a href="mailto:${escapeHtml(business.email)}">${escapeHtml(business.email)}</a><br><a href="tel:${escapeHtml(business.phone.replace(/\s/g, ""))}">${escapeHtml(business.phone)}</a></address><div class="contact-links">${external(business.facebook, "Facebook ↗", "dark-link")}${external(business.maps, "Directions ↗", "dark-link")}</div></div><form class="enquiry reveal"><div><label>Name<input name="name" autocomplete="name" required></label><label>Email<input name="email" type="email" autocomplete="email" required></label></div><label>Preferred artist<select name="artist"><option>No preference</option>${content.artists.map((artist) => `<option>${escapeHtml(artist.name)}</option>`).join("")}</select></label><label>Your idea<textarea name="idea" rows="7" placeholder="Style, placement, approximate size and anything else useful…" required></textarea></label><button class="button light" type="submit">Send demo enquiry →</button><p class="form-status" aria-live="polite"></p></form></section>`;
  }

  function legalPage(kind) {
    const privacy = kind === "privacy";
    return `${pageHero("08", privacy ? "PRIVACY." : "TERMS.", privacy ? "Plain-English information about your data." : "The practical details.")}<section class="sub-content legal"><h2 class="reveal">${privacy ? "YOUR DATA, KEPT SIMPLE." : "A FEW GROUND RULES."}</h2><p class="reveal">${privacy ? "DEMO PLACEHOLDER: replace this with a privacy notice appropriate for your real forms, analytics, mailing list and hosting setup." : "DEMO PLACEHOLDER: replace this with your real booking, deposit, cancellation, age and identification terms."}</p><p class="reveal">This GitHub Pages demo does not send form entries anywhere. Connect your chosen form and newsletter services before launch.</p></section>`;
  }

  function notFoundPage() {
    return `${pageHero("404", "PAGE NOT FOUND.", "That page does not exist in this demo.")}<section class="sub-content not-found"><h2>LOST?<br>START AGAIN.</h2>${routeLink("", "Return home →", "button light")}</section>`;
  }

  const pages = {
    "": homePage,
    "home": homePage,
    "tattoos": tattoosPage,
    "piercing": piercingPage,
    "piercing-prices": pricesPage,
    "artists": artistsPage,
    "studio": studioPage,
    "faq": faqPage,
    "contact": contactPage,
    "privacy": () => legalPage("privacy"),
    "terms": () => legalPage("terms")
  };

  function currentRoute() {
    return location.hash.replace(/^#\/?/, "").split(/[?&]/)[0].replace(/\/$/, "");
  }

  function renderFooter() {
    document.querySelector(".site-footer").innerHTML = `<section class="final-cta"><p class="eyebrow">YOUR IDEA. DONE PROPERLY.</p><h2>READY WHEN<br>YOU ARE.</h2>${routeLink("contact", "Send your idea →", "button light")}</section><div class="footer-grid"><div><strong>ACREEDO</strong><p>${business.addressLines.map(escapeHtml).join("<br>")}</p></div><div><p>${escapeHtml(business.openingHours)}</p></div><div class="footer-links">${routeLink("faq", "FAQ")}${routeLink("privacy", "Privacy")}${routeLink("terms", "Terms")}${external(business.facebook, "Facebook")}</div><p class="footer-word">ACREEDO</p></div>`;
    document.querySelector(".mobile-menu-meta").innerHTML = `${external(business.facebook, "Facebook ↗")}<br>${business.addressLines.map(escapeHtml).join("<br>")}<br><a href="tel:${escapeHtml(business.phone.replace(/\s/g, ""))}">Call the studio</a>`;
  }

  function wireDemoForms() {
    const newsletter = document.querySelector(".newsletter-form");
    if (newsletter) newsletter.addEventListener("submit", (event) => {
      event.preventDefault();
      newsletter.querySelector(".form-status").textContent = "Demo only — connect this form to Mailchimp, Buttondown or another newsletter service.";
    });
    const enquiry = document.querySelector(".enquiry");
    if (enquiry) enquiry.addEventListener("submit", (event) => {
      event.preventDefault();
      enquiry.querySelector(".form-status").textContent = "Demo received. Connect Formspree, Basin or your own form endpoint before launch.";
    });
  }

  let observer;
  function wireReveals() {
    if (observer) observer.disconnect();
    const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const elements = Array.from(document.querySelectorAll(".reveal, .reveal-group > *"));
    if (reduceMotion || !("IntersectionObserver" in window)) {
      elements.forEach((element) => element.classList.add("is-revealed"));
      return;
    }
    observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-revealed");
        observer.unobserve(entry.target);
      }
    }), { threshold: 0.08, rootMargin: "0px 0px -8% 0px" });
    elements.forEach((element, index) => {
      element.style.setProperty("--delay", `${Math.min(index % 5, 4) * 55}ms`);
      observer.observe(element);
    });
    requestAnimationFrame(() => elements.forEach((element) => {
      const box = element.getBoundingClientRect();
      if (box.top < innerHeight * 0.95 && box.bottom > 0) element.classList.add("is-revealed");
    }));
  }

  function render() {
    const route = currentRoute();
    app.innerHTML = (pages[route] || notFoundPage)();
    document.title = route ? `${route.replace(/-/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase())} | ${business.name}` : business.name;
    document.body.classList.toggle("home-page", !route || route === "home");
    document.querySelector(".mobile-menu").classList.remove("open");
    document.querySelector(".mobile-menu").setAttribute("aria-hidden", "true");
    document.querySelector(".menu-button").setAttribute("aria-expanded", "false");
    scrollTo({ top: 0, behavior: "auto" });
    wireDemoForms();
    wireReveals();
  }

  function wireChrome() {
    const header = document.querySelector(".site-header");
    const progress = document.querySelector(".scroll-progress");
    addEventListener("scroll", () => {
      header.classList.toggle("scrolled", scrollY > 40);
      const max = document.documentElement.scrollHeight - innerHeight;
      progress.style.width = `${max > 0 ? (scrollY / max) * 100 : 0}%`;
    }, { passive: true });
    const menu = document.querySelector(".mobile-menu");
    const button = document.querySelector(".menu-button");
    const close = document.querySelector(".menu-close");
    const setMenu = (open) => {
      menu.classList.toggle("open", open);
      menu.setAttribute("aria-hidden", String(!open));
      button.setAttribute("aria-expanded", String(open));
    };
    button.addEventListener("click", () => setMenu(true));
    close.addEventListener("click", () => setMenu(false));
    menu.addEventListener("click", (event) => { if (event.target.closest("a")) setMenu(false); });

    if (matchMedia("(pointer: fine)").matches && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
      const cursor = document.querySelector(".custom-cursor");
      const label = cursor.querySelector("span");
      let x = -100, y = -100, targetX = -100, targetY = -100;
      const draw = () => {
        x += (targetX - x) * 0.2;
        y += (targetY - y) * 0.2;
        cursor.style.transform = `translate3d(${x}px,${y}px,0)`;
        requestAnimationFrame(draw);
      };
      addEventListener("mousemove", (event) => {
        targetX = event.clientX;
        targetY = event.clientY;
        cursor.classList.add("visible");
      });
      addEventListener("mouseover", (event) => {
        const target = event.target.closest("a,button,figure,.artist");
        let word = "";
        if (target && target.closest(".work-grid")) word = "VIEW";
        else if (target && target.closest(".artist-grid,.artist-directory")) word = "EXPLORE";
        else if (target && target.matches(".button,.book-link")) word = "CONTACT";
        cursor.classList.toggle("active", Boolean(target));
        cursor.classList.toggle("labelled", Boolean(word));
        label.textContent = word;
      });
      draw();
    }
  }

  renderFooter();
  wireChrome();
  addEventListener("hashchange", render);
  if (!location.hash) history.replaceState(null, "", "#/" );
  render();
})();
